import { useState, useEffect, useCallback } from "react";

// ====== PRICE CONFIG ======
const PRICE_M_MIN = 55, PRICE_M_MAX = 69;
const PRICE_L_MIN = 79, PRICE_L_MAX = 99;
const PRICE_BANANA = 65;
const PRICE_CREAM = 39;
const MAX_TOPPING_PER_CUP = 45;
const GP_RATE = 0.34;

const PRODUCTS = [
  { key: "m", label: "Size M", unit: "แก้ว" },
  { key: "l", label: "Size L", unit: "แก้ว" },
  { key: "b", label: "จานกระดาษ (บานาน่า สปริท)", unit: "จาน" },
  { key: "c", label: "Size S (ครีมชีสไข่มุก)", unit: "แก้ว" },
];

// ====== LOCAL STORAGE HELPERS ======
const STORAGE_KEY = "bingsu_records";

async function loadAllRecords() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const items = raw ? JSON.parse(raw) : [];
    return items.filter(Boolean).sort((a, b) => b.date.localeCompare(a.date));
  } catch {
    return [];
  }
}

async function saveRecord(rec) {
  const current = await loadAllRecords();
  const updated = [rec, ...current.filter((item) => item.id !== rec.id)];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
}

async function deleteRecord(id) {
  const current = await loadAllRecords();
  const updated = current.filter((item) => item.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
}

// ====== UTILS ======
const fmt = (n) => (isNaN(n) ? "0.00" : n.toLocaleString("th-TH", { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
const num = (v) => parseFloat(v) || 0;
const todayStr = () => new Date().toISOString().split("T")[0];
const soldQty = (prev, add, left) => Math.max(0, num(prev) + num(add) - num(left));

function prevDateOf(dateStr) {
  const d = new Date(dateStr + "T00:00:00");
  d.setDate(d.getDate() - 1);
  return d.toISOString().split("T")[0];
}

function getPrevRemains(records, targetDate) {
  const prevDate = prevDateOf(targetDate);
  const found = records.find((r) => r.date === prevDate);
  if (!found) return null;
  return { m: found.m_left ?? "", l: found.l_left ?? "", b: found.b_left ?? "", c: found.c_left ?? "" };
}

// ====== CSV EXPORT ======
function exportCSV(records) {
  const headers = [
    "วันที่","พนักงาน",
    "M_วันก่อน","M_เติม","M_คงเหลือ","M_ขาย",
    "L_วันก่อน","L_เติม","L_คงเหลือ","L_ขาย",
    "บานาน่า_วันก่อน","บานาน่า_เติม","บานาน่า_คงเหลือ","บานาน่า_ขาย",
    "ครีมชีส_วันก่อน","ครีมชีส_เติม","ครีมชีส_คงเหลือ","ครีมชีส_ขาย",
    "รวมรายการ",
    "เงินโอน_QR","เงินสด",
    "Grab_เต็ม","Grab_สุทธิ","LineMAN_เต็ม","LineMAN_สุทธิ",
    "ยอด_Gross","ยอด_สุทธิร้าน",
    "ช่วงต่ำสุด","ช่วงสูงสุด","สถานะ"
  ];
  const rows = records.map((r) => {
    const res = r.result || {};
    return [
      r.date, r.staff,
      r.m_prev, r.m_add, r.m_left, res.mSold ?? "",
      r.l_prev, r.l_add, r.l_left, res.lSold ?? "",
      r.b_prev, r.b_add, r.b_left, res.bSold ?? "",
      r.c_prev, r.c_add, r.c_left, res.cSold ?? "",
      res.totalCups ?? "",
      r.pay_qr, r.pay_cash,
      r.grab_full, res.grabNet ?? "", r.lineman_full, res.linemanNet ?? "",
      res.grossTotal ?? "", res.netTotal ?? "",
      res.rangeMin ?? "", res.rangeMax ?? "",
      res.statusKey === "ok" ? "ถูกต้อง" : res.statusKey === "low" ? "ยอดน้อย" : res.statusKey === "high" ? "ยอดมาก" : "ไม่มีข้อมูล"
    ].join(",");
  });
  const bom = "\uFEFF";
  const csv = bom + [headers.join(","), ...rows].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `bingsu_${todayStr()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function makeGSheetsTSV(records) {
  const headers = ["วันที่","พนักงาน","M ขาย","L ขาย","บานาน่า ขาย","ครีมชีส ขาย","รวม","QR","เงินสด","Grab(สุทธิ)","LineMAN(สุทธิ)","Gross","สุทธิ","สถานะ"];
  const rows = records.map((r) => {
    const res = r.result || {};
    return [
      r.date, r.staff,
      res.mSold ?? 0, res.lSold ?? 0, res.bSold ?? 0, res.cSold ?? 0,
      res.totalCups ?? 0,
      r.pay_qr || 0, r.pay_cash || 0,
      (res.grabNet ?? 0).toFixed(2), (res.linemanNet ?? 0).toFixed(2),
      (res.grossTotal ?? 0).toFixed(2), (res.netTotal ?? 0).toFixed(2),
      res.statusKey === "ok" ? "✅" : res.statusKey === "low" ? "❌" : res.statusKey === "high" ? "⚠️" : "ℹ️"
    ].join("\t");
  });
  return [headers.join("\t"), ...rows].join("\n");
}

export default function App() {
  const [tab, setTab] = useState("check");
  const [records, setRecords] = useState([]);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const recs = await loadAllRecords();
    setRecords(recs);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  async function onSave(rec) {
    await saveRecord(rec);
    await refresh();
    setEditing(null);
  }

  async function onDelete(id) {
    if (!window.confirm("ลบข้อมูลนี้ใช่ไหม?")) return;
    await deleteRecord(id);
    await refresh();
  }

  function onEdit(rec) {
    setEditing(rec);
    setTab("check");
    window.scrollTo(0, 0);
  }

  return (
    <div style={sx.root}>
      <div style={sx.bgMesh} />
      <div style={sx.wrap}>
        <div style={sx.header}>
          <div style={sx.logoRow}>
            <div style={sx.logoIcon}>🍧</div>
            <div>
              <div style={sx.logoTitle}>บิงซูตู้ส้ม</div>
              <div style={sx.logoSub}>ระบบเช็คยอดขายและสต็อก · เวอร์ชัน GitHub / Vercel</div>
            </div>
            <div style={sx.sharedBadge}>💾 Local</div>
          </div>
          <div style={sx.tabs}>
            {[ ["check","📋 กรอกข้อมูล"], ["history","📊 ประวัติ & ส่งออก"] ].map(([t, l]) => (
              <button key={t} style={{ ...sx.tab, ...(tab === t ? sx.tabOn : {}) }} onClick={() => { setTab(t); if (t === "check") setEditing(null); }}>
                {l}
              </button>
            ))}
          </div>
        </div>

        <div style={sx.sharedNote}>
          ข้อมูลเวอร์ชันนี้เก็บใน <strong>เบราว์เซอร์ของเครื่องที่ใช้งาน</strong> ถ้าเปิดคนละเครื่องจะไม่เห็นข้อมูลร่วมกัน
        </div>

        {loading ? (
          <div style={sx.loading}>🍧 กำลังโหลดข้อมูล...</div>
        ) : tab === "check" ? (
          <Form key={editing?.id ?? "new"} init={editing} records={records} onSave={onSave} />
        ) : (
          <Hist records={records} onEdit={onEdit} onDelete={onDelete} />
        )}
      </div>
    </div>
  );
}

function Form({ init, records, onSave }) {
  const blank = () => ({
    date: todayStr(), staff: "",
    m_prev:"", m_add:"", m_left:"",
    l_prev:"", l_add:"", l_left:"",
    b_prev:"", b_add:"", b_left:"",
    c_prev:"", c_add:"", c_left:"",
    pay_qr:"", pay_cash:"",
    grab_full:"", lineman_full:"",
  });

  const [f, setF] = useState(() => init ? { ...init } : blank());
  const [result, setResult] = useState(init?.result ?? null);
  const [autoFilled, setAutoFilled] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (init) return;
    const prev = getPrevRemains(records, f.date);
    if (prev) {
      setF((p) => ({ ...p, m_prev: prev.m, l_prev: prev.l, b_prev: prev.b, c_prev: prev.c }));
      setAutoFilled(true);
    } else {
      setAutoFilled(false);
    }
  }, [f.date, init, records]);

  const set = (k, v) => {
    setF((p) => ({ ...p, [k]: v }));
    setResult(null);
  };

  function calc() {
    const mSold = soldQty(f.m_prev, f.m_add, f.m_left);
    const lSold = soldQty(f.l_prev, f.l_add, f.l_left);
    const bSold = soldQty(f.b_prev, f.b_add, f.b_left);
    const cSold = soldQty(f.c_prev, f.c_add, f.c_left);
    const totalCups = mSold + lSold + bSold + cSold;
    const minExp = mSold * PRICE_M_MIN + lSold * PRICE_L_MIN + bSold * PRICE_BANANA + cSold * PRICE_CREAM;
    const maxExp = mSold * PRICE_M_MAX + lSold * PRICE_L_MAX + bSold * PRICE_BANANA + cSold * PRICE_CREAM;
    const toppingBuffer = totalCups * MAX_TOPPING_PER_CUP;
    const qr = num(f.pay_qr), cash = num(f.pay_cash);
    const grabFull = num(f.grab_full), linemanFull = num(f.lineman_full);
    const grabNet = grabFull * (1 - GP_RATE), linemanNet = linemanFull * (1 - GP_RATE);
    const grossTotal = qr + cash + grabFull + linemanFull;
    const netTotal = qr + cash + grabNet + linemanNet;
    const rangeMin = minExp, rangeMax = maxExp + toppingBuffer;
    let statusKey, statusColor;
    if (totalCups === 0) {
      statusKey = "nodata"; statusColor = "#94a3b8";
    } else if (grossTotal < rangeMin) {
      statusKey = "low"; statusColor = "#ef4444";
    } else if (grossTotal > rangeMax) {
      statusKey = "high"; statusColor = "#f97316";
    } else {
      statusKey = "ok"; statusColor = "#22c55e";
    }
    return { mSold, lSold, bSold, cSold, totalCups, minExp, maxExp, rangeMin, rangeMax, qr, cash, grabFull, linemanFull, grabNet, linemanNet, grossTotal, netTotal, statusKey, statusColor };
  }

  function handleCalc() {
    setResult(calc());
  }

  async function handleSave() {
    if (!result) {
      window.alert("กรุณากดคำนวณก่อนบันทึก");
      return;
    }
    if (!f.staff.trim()) {
      window.alert("กรุณากรอกชื่อพนักงาน");
      return;
    }
    setSaving(true);
    const rec = { ...f, id: init?.id ?? Date.now().toString(), savedAt: new Date().toISOString(), result };
    await onSave(rec);
    window.alert("✅ บันทึกข้อมูลเรียบร้อย!");
    setSaving(false);
  }

  return (
    <div style={sx.formWrap}>
      <Card title="📅 ข้อมูลทั่วไป">
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <Fld label="วันที่"><input type="date" value={f.date} onChange={(e) => set("date", e.target.value)} style={sx.inp} /></Fld>
          <Fld label="ชื่อพนักงาน"><input type="text" placeholder="ชื่อพนักงาน" value={f.staff} onChange={(e) => set("staff", e.target.value)} style={sx.inp} /></Fld>
        </div>
      </Card>

      <Card title="🍧 จำนวนแก้ว / จาน">
        <div style={sx.hint}>💡 จำนวนขาย = (วันก่อน + เติมเพิ่ม) − คงเหลือ</div>
        {autoFilled && !init && (
          <div style={sx.autoTag}>✨ ดึงยอดคงเหลือจากบันทึก <strong>{prevDateOf(f.date)}</strong> มาให้อัตโนมัติ</div>
        )}
        {PRODUCTS.map((p) => (
          <StockRow key={p.key} label={p.label} unit={p.unit} prev={f[p.key + "_prev"]} add={f[p.key + "_add"]} left={f[p.key + "_left"]} pfx={p.key} set={set} />
        ))}
      </Card>

      <Card title="💰 ยอดเงินที่ได้รับ">
        <div style={sx.paySection}>
          <div style={sx.payLabel}>ยอดหน้าร้าน</div>
          <div style={sx.g2}>
            <Fld label="💳 เงินโอน QR (บาท)"><input type="number" min="0" placeholder="0" value={f.pay_qr} onChange={(e) => set("pay_qr", e.target.value)} style={sx.inp} /></Fld>
            <Fld label="💵 เงินสด (บาท)"><input type="number" min="0" placeholder="0" value={f.pay_cash} onChange={(e) => set("pay_cash", e.target.value)} style={sx.inp} /></Fld>
          </div>
        </div>
        <DelivBlock icon="🚗" name="Grab" full={f.grab_full} setFull={(v) => set("grab_full", v)} />
        <DelivBlock icon="🟢" name="LINE MAN" full={f.lineman_full} setFull={(v) => set("lineman_full", v)} />
      </Card>

      <div style={sx.center}>
        <button style={sx.btnCalc} onClick={handleCalc}>🔍 คำนวณตรวจสอบ</button>
      </div>

      {result && <ResultPanel r={result} onSave={handleSave} isEdit={!!init} saving={saving} />}
    </div>
  );
}

function StockRow({ label, unit, prev, add, left, pfx, set }) {
  const s = soldQty(prev, add, left);
  return (
    <div style={sx.stockRow}>
      <div style={sx.stockLabel}>{label}</div>
      <div style={sx.stockLine}>
        <Fld label="วันก่อน"><input type="number" min="0" placeholder="0" value={prev} onChange={(e) => set(pfx + "_prev", e.target.value)} style={sx.inpSm} /></Fld>
        <Op>+</Op>
        <Fld label="เติมเพิ่ม"><input type="number" min="0" placeholder="0" value={add} onChange={(e) => set(pfx + "_add", e.target.value)} style={sx.inpSm} /></Fld>
        <Op>−</Op>
        <Fld label="คงเหลือ"><input type="number" min="0" placeholder="0" value={left} onChange={(e) => set(pfx + "_left", e.target.value)} style={sx.inpSm} /></Fld>
        <Op>=</Op>
        <div style={sx.soldBox}>
          <div style={sx.soldNum}>{s}</div>
          <div style={sx.soldLbl}>{unit}</div>
        </div>
      </div>
    </div>
  );
}

const Op = ({ children }) => <span style={sx.op}>{children}</span>;

function DelivBlock({ icon, name, full, setFull }) {
  const f = num(full);
  const net = f * (1 - GP_RATE);
  return (
    <div style={sx.delivBlock}>
      <div style={sx.payLabel}>{icon} {name} <span style={sx.gpBadge}>GP 34%</span></div>
      <div style={sx.g2}>
        <Fld label="ราคาเต็ม (ก่อนหัก GP)">
          <input type="number" min="0" placeholder="0" value={full} onChange={(e) => setFull(e.target.value)} style={sx.inp} />
        </Fld>
        <Fld label="ร้านได้รับจริง (หลังหัก 34%)">
          <div style={sx.calcOut}>{fmt(net)} ฿</div>
        </Fld>
      </div>
    </div>
  );
}

const STATUS = {
  ok: { icon: "✅", title: "ยอดถูกต้อง!", desc: (r) => `ยอดเงิน ${fmt(r.grossTotal)} ฿ อยู่ในช่วงที่เป็นไปได้ (${fmt(r.rangeMin)} – ${fmt(r.rangeMax)} ฿)` },
  low: { icon: "❌", title: "ยอดเงินน้อยกว่าที่ควร", desc: (r) => `ยอดเงิน ${fmt(r.grossTotal)} ฿ ต่ำกว่าขั้นต่ำ ${fmt(r.rangeMin)} ฿ อยู่ ${fmt(r.rangeMin - r.grossTotal)} ฿` },
  high: { icon: "⚠️", title: "ยอดเงินมากกว่าที่ควร", desc: (r) => `ยอดเงิน ${fmt(r.grossTotal)} ฿ เกินช่วงสูงสุด ${fmt(r.rangeMax)} ฿ อยู่ ${fmt(r.grossTotal - r.rangeMax)} ฿` },
  nodata: { icon: "ℹ️", title: "ยังไม่มีข้อมูล", desc: () => "กรุณากรอกจำนวนแก้ว/จานก่อนคำนวณ" },
};

function ResultPanel({ r, onSave, isEdit, saving }) {
  const st = STATUS[r.statusKey];
  return (
    <div style={{ ...sx.resBox, borderColor: r.statusColor }}>
      <div style={{ ...sx.resBanner, background: r.statusColor }}>{st.icon} {st.title}</div>
      <div style={sx.resBody}>
        <div style={sx.resMsg}>{st.desc(r)}</div>
        <Divider />
        <Sub>📦 จำนวนที่ขายได้</Sub>
        <Row l="Size M" v={`${r.mSold} แก้ว`} />
        <Row l="Size L" v={`${r.lSold} แก้ว`} />
        <Row l="จานกระดาษ (บานาน่า สปริท)" v={`${r.bSold} จาน`} />
        <Row l="Size S (ครีมชีสไข่มุก)" v={`${r.cSold} แก้ว`} />
        <Row l="รวมทั้งหมด" v={`${r.totalCups} รายการ`} bold />
        <Divider />
        <Sub>💰 ยอดเงิน</Sub>
        <Row l="ช่วงที่ยอมรับ (รวม topping สูงสุด)" v={`${fmt(r.rangeMin)} – ${fmt(r.rangeMax)} ฿`} muted />
        <Row l="💳 เงินโอน QR" v={`${fmt(r.qr)} ฿`} />
        <Row l="💵 เงินสด" v={`${fmt(r.cash)} ฿`} />
        {r.grabFull > 0 && <Row l="🚗 Grab → หลังหัก GP" v={`${fmt(r.grabNet)} ฿`} />}
        {r.linemanFull > 0 && <Row l="🟢 LINE MAN → หลังหัก GP" v={`${fmt(r.linemanNet)} ฿`} />}
        <Divider />
        <Row l="ยอดลูกค้าจ่ายรวม (gross)" v={`${fmt(r.grossTotal)} ฿`} bold accent />
        <Row l="ยอดที่ร้านได้รับสุทธิ" v={`${fmt(r.netTotal)} ฿`} bold />
      </div>
      <button style={{ ...sx.btnSave, background: saving ? "#94a3b8" : r.statusKey === "ok" ? "#1c1917" : r.statusColor, opacity: saving ? 0.7 : 1 }} onClick={onSave} disabled={saving}>
        {saving ? "⏳ กำลังบันทึก..." : isEdit ? "💾 อัปเดตข้อมูล" : "💾 บันทึกข้อมูลวันนี้"}
      </button>
    </div>
  );
}

const Divider = () => <div style={sx.divider} />;
const Sub = ({ children }) => <div style={sx.sub}>{children}</div>;

function Row({ l, v, bold, accent, muted }) {
  return (
    <div style={sx.row}>
      <span style={{ fontSize: 13, color: muted ? "#a8a29e" : "#78716c", ...(bold ? { fontWeight: 700 } : {}) }}>{l}</span>
      <span style={{ fontSize: 14, color: accent ? "#f97316" : "#1c1917", ...(bold ? { fontWeight: 700 } : {}) }}>{v}</span>
    </div>
  );
}

function Hist({ records, onEdit, onDelete }) {
  const [q, setQ] = useState("");
  const [copied, setCopied] = useState(false);
  const list = records.filter((r) => r.date?.includes(q) || r.staff?.includes(q));

  function handleExportCSV() {
    exportCSV(list.length ? list : records);
  }

  function handleCopyForSheets() {
    const tsv = makeGSheetsTSV(list.length ? list : records);
    navigator.clipboard.writeText(tsv).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  }

  if (!records.length) {
    return (
      <div style={sx.empty}>
        <div style={{ fontSize: 48 }}>📭</div>
        <div>ยังไม่มีข้อมูลที่บันทึก</div>
        <div style={{ fontSize: 13, opacity: 0.5, marginTop: 4 }}>กรอกและบันทึกในแท็บ "กรอกข้อมูล"</div>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <div style={sx.exportBox}>
        <div style={sx.exportTitle}>📤 ส่งออกข้อมูล</div>
        <div style={sx.exportRow}>
          <button style={sx.btnExport} onClick={handleExportCSV}>
            📊 ดาวน์โหลด CSV<br /><span style={{ fontSize: 11, opacity: 0.8 }}>สำหรับ Excel</span>
          </button>
          <button style={{ ...sx.btnExport, background: copied ? "#22c55e" : "#1e40af" }} onClick={handleCopyForSheets}>
            {copied ? "✅ คัดลอกแล้ว!" : "📋 คัดลอกสำหรับ Google Sheets"}<br />
            <span style={{ fontSize: 11, opacity: 0.8 }}>{copied ? "วาง (Ctrl+V) ใน Sheets ได้เลย" : "แล้ววาง Ctrl+V ใน Sheets"}</span>
          </button>
        </div>
        <div style={sx.exportHint}>💡 <strong>วิธีนำเข้า Google Sheets:</strong> กดคัดลอก → เปิด Google Sheets → คลิกเซลล์ A1 → กด Ctrl+V</div>
      </div>

      <input style={sx.inp} placeholder="🔍 ค้นหาวันที่หรือชื่อพนักงาน" value={q} onChange={(e) => setQ(e.target.value)} />
      <div style={sx.recordCount}>{list.length} รายการ {q ? `(กรอง "${q}")` : "ทั้งหมด"}</div>
      {list.map((r) => <HistCard key={r.id} record={r} onEdit={onEdit} onDelete={onDelete} />)}
    </div>
  );
}

function HistCard({ record, onEdit, onDelete }) {
  const [open, setOpen] = useState(false);
  const { result: r } = record;
  const st = STATUS[r.statusKey];
  return (
    <div style={{ ...sx.hCard, borderLeft: `4px solid ${r.statusColor}` }}>
      <div style={sx.hHead} onClick={() => setOpen((o) => !o)}>
        <div>
          <div style={{ fontSize: 16, fontWeight: 700, color: "#1c1917" }}>
            {record.date} <span style={{ fontSize: 13, color: "#94a3b8" }}>{open ? "▲" : "▼"}</span>
          </div>
          <div style={{ fontSize: 13, color: "#78716c", marginTop: 2 }}>{record.staff || "ไม่ระบุชื่อ"}</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: r.statusColor, marginBottom: 2 }}>{st.icon} {r.statusKey === "ok" ? "ถูกต้อง" : "ไม่ตรง"}</div>
          <div style={{ fontSize: 18, fontWeight: 800, color: "#f97316" }}>{fmt(r.grossTotal)} ฿</div>
          <div style={{ fontSize: 12, color: "#78716c" }}>{r.totalCups} รายการ • สุทธิ {fmt(r.netTotal)} ฿</div>
        </div>
      </div>
      {open && (
        <div style={sx.hBody}>
          <div style={sx.hGrid}>
            <span>Size M / L</span><span>{r.mSold} / {r.lSold} แก้ว</span>
            <span>บานาน่า สปริท</span><span>{r.bSold} จาน</span>
            <span>Size S (ครีมชีส)</span><span>{r.cSold} แก้ว</span>
            <span>ช่วงที่ยอมรับ</span><span>{fmt(r.rangeMin)} – {fmt(r.rangeMax)} ฿</span>
            <span>ยอด gross</span><span style={{ fontWeight: 700 }}>{fmt(r.grossTotal)} ฿</span>
            <span>ยอดสุทธิร้าน</span><span style={{ fontWeight: 700, color: "#f97316" }}>{fmt(r.netTotal)} ฿</span>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button style={sx.btnEd} onClick={() => onEdit(record)}>✏️ แก้ไข</button>
            <button style={sx.btnDel} onClick={() => onDelete(record.id)}>🗑️ ลบ</button>
          </div>
        </div>
      )}
    </div>
  );
}

function Card({ title, children }) {
  return <div style={sx.card}><div style={sx.cardTitle}>{title}</div>{children}</div>;
}

function Fld({ label, children }) {
  return <div style={sx.field}><label style={sx.fldLbl}>{label}</label>{children}</div>;
}

const sx = {
  root: { minHeight: "100vh", background: "#fff8f0", fontFamily: "'Sarabun','Noto Sans Thai',sans-serif", position: "relative" },
  bgMesh: { position: "fixed", inset: 0, backgroundImage: "radial-gradient(circle at 80% 10%, #fed7aa33 0%, transparent 50%), radial-gradient(circle at 10% 90%, #fde68a22 0%, transparent 50%)", pointerEvents: "none" },
  wrap: { maxWidth: 700, margin: "0 auto", padding: "16px 12px 60px" },
  header: { background: "linear-gradient(135deg,#f97316,#ea580c)", borderRadius: 20, padding: "20px 20px 0", marginBottom: 10, boxShadow: "0 8px 24px #f9731640" },
  logoRow: { display: "flex", alignItems: "center", gap: 12, marginBottom: 16 },
  logoIcon: { fontSize: 44, filter: "drop-shadow(0 2px 6px #0004)" },
  logoTitle: { color: "#fff", fontSize: 22, fontWeight: 800 },
  logoSub: { color: "#fed7aa", fontSize: 12 },
  sharedBadge: { marginLeft: "auto", background: "#ffffff25", color: "#fff", borderRadius: 20, padding: "4px 12px", fontSize: 12, fontWeight: 700, backdropFilter: "blur(4px)", border: "1px solid #ffffff30" },
  tabs: { display: "flex", gap: 4 },
  tab: { flex: 1, padding: "10px 0", borderRadius: "10px 10px 0 0", border: "none", cursor: "pointer", fontSize: 13, fontWeight: 600, background: "#c2410c44", color: "#fed7aa", transition: "all .2s" },
  tabOn: { background: "#fff8f0", color: "#f97316" },
  sharedNote: { background: "#fffbeb", border: "1px solid #fde68a", borderRadius: 10, padding: "8px 12px", fontSize: 12, color: "#92400e", marginBottom: 10 },
  loading: { display: "flex", alignItems: "center", justifyContent: "center", gap: 10, padding: "60px 20px", fontSize: 16, color: "#78716c" },
  formWrap: { display: "flex", flexDirection: "column", gap: 12 },
  card: { background: "#fff", borderRadius: 16, padding: "16px 16px 14px", boxShadow: "0 2px 8px #0000000a", border: "1px solid #e7e5e4" },
  cardTitle: { fontSize: 15, fontWeight: 700, color: "#f97316", marginBottom: 12 },
  hint: { fontSize: 12, color: "#c2410c", background: "#fff7ed", border: "1px solid #fed7aa", borderRadius: 8, padding: "6px 10px", marginBottom: 8 },
  autoTag: { fontSize: 12, color: "#065f46", background: "#d1fae5", border: "1px solid #6ee7b7", borderRadius: 8, padding: "6px 10px", marginBottom: 12 },
  g2: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 },
  field: { display: "flex", flexDirection: "column", gap: 4, flex: 1 },
  fldLbl: { fontSize: 12, color: "#78716c", fontWeight: 600 },
  inp: { padding: "9px 12px", borderRadius: 10, border: "1.5px solid #e7e5e4", fontSize: 14, background: "#fafaf9", outline: "none", fontFamily: "inherit", width: "100%", boxSizing: "border-box" },
  inpSm: { padding: "8px 6px", borderRadius: 8, border: "1.5px solid #e7e5e4", fontSize: 15, background: "#fafaf9", outline: "none", textAlign: "center", fontWeight: 700, fontFamily: "inherit", width: "100%", boxSizing: "border-box" },
  calcOut: { padding: "9px 12px", borderRadius: 10, border: "1.5px solid #d1fae5", fontSize: 14, background: "#f0fdf4", fontWeight: 700, color: "#166534" },
  stockRow: { marginBottom: 14 },
  stockLabel: { fontSize: 13, fontWeight: 700, color: "#1c1917", marginBottom: 6 },
  stockLine: { display: "flex", alignItems: "flex-end", gap: 4, overflowX: "auto" },
  op: { fontSize: 18, fontWeight: 700, color: "#78716c", paddingBottom: 8, flexShrink: 0 },
  soldBox: { background: "#fff7ed", border: "2px solid #fed7aa", borderRadius: 10, padding: "4px 10px", textAlign: "center", flexShrink: 0, minWidth: 56 },
  soldNum: { fontSize: 20, fontWeight: 800, color: "#f97316", lineHeight: 1 },
  soldLbl: { fontSize: 10, color: "#78716c" },
  paySection: { marginBottom: 14 },
  payLabel: { fontSize: 13, fontWeight: 700, color: "#1c1917", marginBottom: 8, display: "flex", alignItems: "center", gap: 6 },
  gpBadge: { fontSize: 11, background: "#fef3c7", color: "#92400e", borderRadius: 6, padding: "1px 7px", fontWeight: 700 },
  delivBlock: { paddingTop: 10, borderTop: "1px solid #e7e5e4", marginBottom: 14 },
  center: { display: "flex", justifyContent: "center" },
  btnCalc: { background: "#f97316", color: "#fff", border: "none", borderRadius: 12, padding: "13px 44px", fontSize: 16, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 14px #f9731650" },
  resBox: { background: "#fff", borderRadius: 16, border: "2px solid", overflow: "hidden", boxShadow: "0 4px 16px #0000001a" },
  resBanner: { color: "#fff", padding: "13px 20px", fontSize: 17, fontWeight: 800 },
  resBody: { padding: "14px 16px", display: "flex", flexDirection: "column", gap: 5 },
  resMsg: { fontSize: 13, color: "#1c1917", background: "#f5f5f4", borderRadius: 8, padding: "8px 12px", lineHeight: 1.5 },
  sub: { fontSize: 12, fontWeight: 700, color: "#78716c", marginTop: 4 },
  row: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 },
  divider: { height: 1, background: "#e7e5e4", margin: "4px 0" },
  btnSave: { display: "block", width: "calc(100% - 32px)", margin: "0 16px 16px", color: "#fff", border: "none", borderRadius: 12, padding: "13px", fontSize: 15, fontWeight: 700, cursor: "pointer", transition: "all .2s" },
  exportBox: { background: "#fff", borderRadius: 16, padding: "16px", border: "2px solid #bfdbfe", boxShadow: "0 2px 8px #0000000a" },
  exportTitle: { fontSize: 14, fontWeight: 700, color: "#1e40af", marginBottom: 10 },
  exportRow: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 10 },
  btnExport: { background: "#1e40af", color: "#fff", border: "none", borderRadius: 10, padding: "12px 8px", fontSize: 13, fontWeight: 700, cursor: "pointer", lineHeight: 1.4, textAlign: "center", transition: "all .2s" },
  exportHint: { fontSize: 12, color: "#1e40af", background: "#eff6ff", borderRadius: 8, padding: "8px 10px" },
  recordCount: { fontSize: 12, color: "#78716c", textAlign: "right" },
  empty: { background: "#fff", borderRadius: 16, padding: "48px 20px", textAlign: "center", color: "#78716c", fontSize: 16, border: "1px solid #e7e5e4" },
  hCard: { background: "#fff", borderRadius: 14, border: "1px solid #e7e5e4", overflow: "hidden", boxShadow: "0 2px 8px #0000000a" },
  hHead: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", padding: "14px 16px", cursor: "pointer", gap: 12 },
  hBody: { borderTop: "1px solid #e7e5e4", padding: "12px 16px" },
  hGrid: { display: "grid", gridTemplateColumns: "1fr auto", gap: "6px 16px", fontSize: 13, marginBottom: 10, color: "#78716c" },
  btnEd: { flex: 1, padding: "8px", borderRadius: 8, border: "1.5px solid #e7e5e4", background: "#fff", fontSize: 13, fontWeight: 600, cursor: "pointer" },
  btnDel: { flex: 1, padding: "8px", borderRadius: 8, border: "1.5px solid #fecaca", background: "#fff5f5", color: "#ef4444", fontSize: 13, fontWeight: 600, cursor: "pointer" },
};
