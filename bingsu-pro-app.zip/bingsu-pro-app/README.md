# Bingsu Pro App

เว็บแอปสำหรับเช็คยอดขายและสต็อกบิงซู เวอร์ชันพร้อม deploy บน GitHub + Vercel

## วิธีใช้งานในเครื่อง

```bash
npm install
npm start
```

## Deploy บน Vercel
- อัปโหลดไฟล์ทั้งหมดขึ้น GitHub
- Import repository นี้ใน Vercel
- Deploy ได้ทันที

หมายเหตุ: เวอร์ชันนี้ใช้ `localStorage` ดังนั้นข้อมูลจะเก็บในเบราว์เซอร์ของแต่ละเครื่อง
